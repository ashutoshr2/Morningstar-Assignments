var app = angular.module('app', []);
app.controller("myController", function ($scope, $http, $window) {
    $http({
        method: 'Get',
        url: 'http://rpsbeta.morningstar.com/api/v2/167975617/documents?fields=Id,Title,Authors(Id,Name),keywords(name)&format=json'
    }).then(function (response) {
        $scope.requestData = response.data;
    });
});
app.directive('gridView', function () {
    function parseSelectedCols(str) {
        var i;
        var paresedCols = str.split(",");
        for (i = 0; i < paresedCols.length; i++) {
            paresedCols[i] = paresedCols[i];
        }
        return paresedCols;
    }
    return {
        template: '<table border=1>'+
   '<tr>'+
      '<th ng-repeat="onlyselectedcol in selectedCols">{{onlyselectedcol}}</th>'+

   '</tr>'+
   '<tr ng-repeat="alldata in data">'+
      '<td ng-repeat="onlyselectedcol in selectedCols"><div ng-switch="onlyselectedcol">'+
  '<div ng-switch-when="Authors">{{"abc"}}</div>'+
  '<div ng-switch-default>{{alldata[onlyselectedcol]}}</div>'+
'</div></td>'+
   '</tr>'+
'</table>'/*+
'{{selectedCols}}'+
'{{data}}*/,
        restrict: 'E',
        scope: {
            data: '='
        },
        link: function (scope, elem, attrs) {
            scope.selectedCols = parseSelectedCols(attrs.headers);
        }
    };
});